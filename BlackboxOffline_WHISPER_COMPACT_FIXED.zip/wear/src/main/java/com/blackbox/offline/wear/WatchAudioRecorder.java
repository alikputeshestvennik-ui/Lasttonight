package com.blackbox.offline.wear;

import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.PowerManager;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.UUID;

/**
 * Robust Wear OS Audio Recorder for Galaxy Watch 4 / 5 / 6 / 7 / 8.
 * Automatically discovers supported AudioSource and sample rates (16kHz, 44.1kHz, 48kHz).
 * Automatically downsamples to standard 16 kHz 16-bit Mono PCM for Whisper STT.
 */
public class WatchAudioRecorder {
    public interface Callback {
        void onRecordingStarted();
        void onRecordingFinished(File wavFile);
        void onRecordingError(String error);
    }

    private static final int TARGET_RATE = 16000;
    private static final int[] SAMPLE_RATES = new int[]{16000, 44100, 48000, 8000};
    private static final int[] AUDIO_SOURCES = new int[]{
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.DEFAULT
    };

    private final Context context;
    private final Callback callback;
    private AudioRecord audioRecord;
    private Thread recordingThread;
    private PowerManager.WakeLock wakeLock;
    private volatile boolean isRecording = false;
    private int activeSampleRate = 16000;

    public WatchAudioRecorder(Context context, Callback callback) {
        this.context = context.getApplicationContext();
        this.callback = callback;
    }

    public synchronized boolean isRecording() {
        return isRecording;
    }

    public synchronized void start() {
        if (isRecording) return;

        AudioRecord record = null;
        int chosenRate = 16000;

        for (int source : AUDIO_SOURCES) {
            for (int rate : SAMPLE_RATES) {
                try {
                    int minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
                    if (minBuf > 0) {
                        int bufSize = Math.max(minBuf * 2, 4096);
                        AudioRecord candidate = new AudioRecord(source, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufSize);
                        if (candidate.getState() == AudioRecord.STATE_INITIALIZED) {
                            record = candidate;
                            chosenRate = rate;
                            break;
                        } else {
                            candidate.release();
                        }
                    }
                } catch (Throwable ignored) {}
            }
            if (record != null) break;
        }

        if (record == null) {
            if (callback != null) callback.onRecordingError("Микрофон часов недоступен");
            return;
        }

        this.audioRecord = record;
        this.activeSampleRate = chosenRate;

        try {
            PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "BlackboxWatch:Mic");
                wakeLock.acquire(15 * 60 * 1000L);
            }

            audioRecord.startRecording();
            isRecording = true;

            if (callback != null) callback.onRecordingStarted();

            recordingThread = new Thread(this::recordLoop, "WatchAudioRecorderThread");
            recordingThread.start();
        } catch (Throwable t) {
            isRecording = false;
            releaseMic();
            if (callback != null) callback.onRecordingError("Ошибка старта записи: " + t.getMessage());
        }
    }

    private void recordLoop() {
        ByteArrayOutputStream pcmStream = new ByteArrayOutputStream();
        byte[] buffer = new byte[2048];

        try {
            while (isRecording && audioRecord != null) {
                int read = audioRecord.read(buffer, 0, buffer.length);
                if (read > 0) {
                    pcmStream.write(buffer, 0, read);
                }
            }
        } catch (Throwable ignored) {}

        byte[] rawPcm = pcmStream.toByteArray();
        releaseMic();

        if (rawPcm.length < (activeSampleRate * 1.5)) {
            // Less than ~0.75 sec
            if (callback != null) callback.onRecordingError("Слишком короткая запись");
            return;
        }

        // Resample to TARGET_RATE (16000 Hz) if hardware recorded at 44.1k or 48k
        byte[] target16kPcm = (activeSampleRate == TARGET_RATE)
                ? rawPcm
                : resamplePcm16Mono(rawPcm, activeSampleRate, TARGET_RATE);

        try {
            File dir = new File(context.getCacheDir(), "watch_audio");
            dir.mkdirs();
            File wavFile = new File(dir, "watch_" + UUID.randomUUID().toString() + ".wav");
            writeWavHeader(wavFile, target16kPcm, TARGET_RATE);

            if (callback != null) {
                callback.onRecordingFinished(wavFile);
            }
        } catch (Throwable t) {
            if (callback != null) callback.onRecordingError("Ошибка сохранения WAV: " + t.getMessage());
        }
    }

    public synchronized void stop() {
        if (!isRecording) return;
        isRecording = false;
    }

    private synchronized void releaseMic() {
        if (audioRecord != null) {
            try { audioRecord.stop(); } catch (Throwable ignored) {}
            try { audioRecord.release(); } catch (Throwable ignored) {}
            audioRecord = null;
        }
        if (wakeLock != null && wakeLock.isHeld()) {
            try { wakeLock.release(); } catch (Throwable ignored) {}
            wakeLock = null;
        }
    }

    private static byte[] resamplePcm16Mono(byte[] input, int srcRate, int dstRate) {
        int inSamples = input.length / 2;
        int outSamples = (int) ((long) inSamples * dstRate / srcRate);
        byte[] output = new byte[outSamples * 2];

        short[] inShorts = new short[inSamples];
        for (int i = 0; i < inSamples; i++) {
            inShorts[i] = (short) ((input[i * 2] & 0xFF) | (input[i * 2 + 1] << 8));
        }

        for (int i = 0; i < outSamples; i++) {
            double srcIdx = (double) i * srcRate / dstRate;
            int idxFloor = (int) srcIdx;
            int idxCeil = Math.min(idxFloor + 1, inSamples - 1);
            double frac = srcIdx - idxFloor;

            short sample = (short) Math.round(inShorts[idxFloor] * (1.0 - frac) + inShorts[idxCeil] * frac);
            output[i * 2] = (byte) (sample & 0xFF);
            output[i * 2 + 1] = (byte) ((sample >> 8) & 0xFF);
        }
        return output;
    }

    private static void writeWavHeader(File f, byte[] p, int rate) throws Exception {
        try (FileOutputStream o = new FileOutputStream(f)) {
            o.write("RIFF".getBytes());
            le(o, 36 + p.length);
            o.write("WAVEfmt ".getBytes());
            le(o, 16);
            o.write(new byte[]{1, 0, 1, 0}); // PCM, mono
            le(o, rate);
            le(o, rate * 2);
            o.write(new byte[]{2, 0, 16, 0}); // 2 bytes per sample, 16-bit
            o.write("data".getBytes());
            le(o, p.length);
            o.write(p);
            o.flush();
        }
    }

    private static void le(OutputStream o, int n) throws Exception {
        o.write(n);
        o.write(n >> 8);
        o.write(n >> 16);
        o.write(n >> 24);
    }
}
