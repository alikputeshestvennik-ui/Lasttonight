package com.blackbox.offline;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;

public class SummaryActivity extends Activity {
    private EditText dateInput;
    private LinearLayout resultContainer;
    private Button copyBtn;
    private String currentFullText = "";
    private LocalAiEngine aiEngine;
    private MediaPlayer player;
    private String currentlyPlayingAudioPath = null;
    private TextView activePlayingBadge = null;

    @Override
    public void onCreate(Bundle b) {
        super.onCreate(b);
        aiEngine = new LocalAiEngine(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(UI.COLOR_BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int padH = UI.dp(this, 18);
        int padV = UI.dp(this, 20);
        root.setPadding(padH, padV, padH, padV);

        // Header (Galaxy AI style clean)
        root.addView(UI.createHeader(this, "AI-Сводка дня", "Интеллектуальный синтез и кликабельные таймкоды", true));

        // Date selection card
        LinearLayout inputCard = UI.createCard(this);

        TextView labelDate = new TextView(this);
        labelDate.setText("ДАТА СВОДКИ");
        labelDate.setTextColor(UI.COLOR_TEXT_SUBTLE);
        labelDate.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        labelDate.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        labelDate.setPadding(0, 0, 0, UI.dp(this, 8));
        inputCard.addView(labelDate);

        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        dateInput = UI.inputField(this, "ГГГГ-ММ-ДД (например: " + today + ")");
        dateInput.setText(today);
        inputCard.addView(dateInput);

        // Date quick preset chips
        LinearLayout presetRow = new LinearLayout(this);
        presetRow.setOrientation(LinearLayout.HORIZONTAL);
        presetRow.setPadding(0, UI.dp(this, 8), 0, 0);

        Button btnToday = createPresetChip("Сегодня", today);
        presetRow.addView(btnToday);

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -1);
        String yesterday = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime());
        Button btnYesterday = createPresetChip("Вчера", yesterday);
        LinearLayout.LayoutParams ylp = new LinearLayout.LayoutParams(-2, -2);
        ylp.leftMargin = UI.dp(this, 8);
        presetRow.addView(btnYesterday, ylp);

        inputCard.addView(presetRow);

        Button makeBtn = UI.primaryButton(this, "✨ Сформировать AI-сводку");
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(-1, -2);
        btnLp.topMargin = UI.dp(this, 14);
        makeBtn.setOnClickListener(v -> generateSummary());
        inputCard.addView(makeBtn, btnLp);

        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = UI.dp(this, 18);
        root.addView(inputCard, cardLp);

        // Results Container
        resultContainer = new LinearLayout(this);
        resultContainer.setOrientation(LinearLayout.VERTICAL);

        LinearLayout placeholderCard = UI.createCard(this);
        TextView phText = new TextView(this);
        phText.setText("Выберите дату и нажмите кнопку для когнитивной суммаризации аудиозаписей в стиле Galaxy AI.");
        phText.setTextColor(UI.COLOR_TEXT_MUTED);
        phText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        phText.setLineSpacing(UI.dp(this, 4), 1.0f);
        placeholderCard.addView(phText);
        resultContainer.addView(placeholderCard);

        root.addView(resultContainer);

        scroll.addView(root);
        setContentView(scroll);
    }

    private Button createPresetChip(String title, String dateVal) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        b.setAllCaps(false);
        b.setTextColor(UI.COLOR_TEXT_MUTED);
        b.setBackground(UI.buttonRipple(UI.shape(0xFF161A22, UI.COLOR_BORDER, 8, this), 0x33F47721));
        int padH = UI.dp(this, 12);
        int padV = UI.dp(this, 6);
        b.setPadding(padH, padV, padH, padV);
        b.setOnClickListener(v -> {
            dateInput.setText(dateVal);
            generateSummary();
        });
        return b;
    }

    private void generateSummary() {
        stopPlayback();

        String targetDate = dateInput.getText().toString().trim();
        if (targetDate.isEmpty()) {
            targetDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        }

        List<Entry> dayEntries = new ArrayList<>();
        for (Entry e : new EntryStore(this).all()) {
            if (e.created != null && e.created.startsWith(targetDate)
                    && e.transcript != null && !e.transcript.trim().isEmpty()) {
                dayEntries.add(e);
            }
        }

        resultContainer.removeAllViews();

        if (dayEntries.isEmpty()) {
            currentFullText = "";
            LinearLayout emptyCard = UI.createCard(this);
            TextView empty = new TextView(this);
            empty.setText("За дату " + targetDate + " готовых расшифрованных записей не найдено.");
            empty.setTextColor(UI.COLOR_TEXT_MUTED);
            empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            emptyCard.addView(empty);
            resultContainer.addView(emptyCard);
            return;
        }

        QwenEngine.DaySummary summary = aiEngine.summarizeDay(dayEntries, targetDate);
        currentFullText = summary.formattedText;

        // 1. Executive Brief Card (Galaxy AI Overview)
        LinearLayout overviewCard = UI.createCard(this);

        LinearLayout headRow = new LinearLayout(this);
        headRow.setOrientation(LinearLayout.HORIZONTAL);
        headRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView ovTitle = new TextView(this);
        ovTitle.setText("✨ AI-РЕЗЮМЕ ДНЯ");
        ovTitle.setTextColor(UI.COLOR_TEXT_ORANGE);
        ovTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        ovTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        headRow.addView(ovTitle);

        View sp = new View(this);
        headRow.addView(sp, new LinearLayout.LayoutParams(0, 1, 1.0f));

        copyBtn = UI.secondaryButton(this, "Скопировать сводку");
        copyBtn.setOnClickListener(v -> {
            if (!currentFullText.isEmpty()) {
                UI.copyToClipboard(this, "AI-Сводка", currentFullText);
            }
        });
        headRow.addView(copyBtn);
        overviewCard.addView(headRow);

        TextView ovText = new TextView(this);
        ovText.setText(summary.executiveBrief);
        ovText.setTextColor(UI.COLOR_TEXT_PRIMARY);
        ovText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        ovText.setLineSpacing(UI.dp(this, 4), 1.0f);
        ovText.setPadding(0, UI.dp(this, 10), 0, 0);
        overviewCard.addView(ovText);

        LinearLayout.LayoutParams ovLp = new LinearLayout.LayoutParams(-1, -2);
        ovLp.bottomMargin = UI.dp(this, 16);
        resultContainer.addView(overviewCard, ovLp);

        // 2. Render Interactive Galaxy AI Section Cards
        renderSection("🎯 Главное и фокус дня", summary.priorities);
        renderSection("📌 Задачи к выполнению", summary.tasks);
        renderSection("🤝 Встречи и договорённости", summary.meetings);
        renderSection("💡 Идеи и гипотезы", summary.ideas);
        renderSection("📝 Хроника событий", summary.chronicle);
    }

    private void renderSection(String sectionTitle, List<QwenEngine.SummaryItem> items) {
        if (items == null || items.isEmpty()) return;

        TextView titleView = new TextView(this);
        titleView.setText(sectionTitle);
        titleView.setTextColor(UI.COLOR_TEXT_TITLE);
        titleView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        titleView.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        titleView.setPadding(UI.dp(this, 4), UI.dp(this, 12), 0, UI.dp(this, 8));
        resultContainer.addView(titleView);

        for (QwenEngine.SummaryItem item : items) {
            LinearLayout itemCard = item.isImportant ? UI.createImportantCard(this) : UI.createCard(this);
            itemCard.setOrientation(LinearLayout.VERTICAL);
            int pad = UI.dp(this, 14);
            itemCard.setPadding(pad, pad, pad, pad);

            // Top row: Clickable Audio Timecode + Headline
            LinearLayout headRow = new LinearLayout(this);
            headRow.setOrientation(LinearLayout.HORIZONTAL);
            headRow.setGravity(Gravity.CENTER_VERTICAL);

            TextView timeBadge = new TextView(this);
            timeBadge.setText("▶ " + item.time);
            timeBadge.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            timeBadge.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            timeBadge.setTextColor(UI.COLOR_ORANGE_LIGHT);
            timeBadge.setBackground(UI.buttonRipple(UI.shape(0xFF221710, UI.COLOR_ORANGE_BORDER, 8, this), 0x33F47721));
            int bPadH = UI.dp(this, 10);
            int bPadV = UI.dp(this, 5);
            timeBadge.setPadding(bPadH, bPadV, bPadH, bPadV);
            timeBadge.setOnClickListener(v -> toggleAudio(item, timeBadge));
            headRow.addView(timeBadge);

            TextView headlineView = new TextView(this);
            headlineView.setText(item.formattedHeadline);
            headlineView.setTextColor(UI.COLOR_TEXT_TITLE);
            headlineView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
            headlineView.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            LinearLayout.LayoutParams hLp = new LinearLayout.LayoutParams(0, -2, 1.0f);
            hLp.leftMargin = UI.dp(this, 10);
            headlineView.setLayoutParams(hLp);
            headRow.addView(headlineView);

            itemCard.addView(headRow);

            // Refined text content
            TextView bodyText = new TextView(this);
            bodyText.setText(item.refinedText);
            bodyText.setTextColor(UI.COLOR_TEXT_PRIMARY);
            bodyText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
            bodyText.setLineSpacing(UI.dp(this, 3), 1.0f);
            bodyText.setPadding(0, UI.dp(this, 8), 0, 0);
            itemCard.addView(bodyText);

            // Sub bullet points if extracted
            if (item.bulletPoints != null && !item.bulletPoints.isEmpty()) {
                LinearLayout bulletCol = new LinearLayout(this);
                bulletCol.setOrientation(LinearLayout.VERTICAL);
                bulletCol.setPadding(UI.dp(this, 8), UI.dp(this, 6), 0, 0);
                for (String bullet : item.bulletPoints) {
                    TextView btv = new TextView(this);
                    btv.setText("• " + bullet);
                    btv.setTextColor(UI.COLOR_TEXT_MUTED);
                    btv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
                    btv.setPadding(0, UI.dp(this, 2), 0, UI.dp(this, 2));
                    bulletCol.addView(btv);
                }
                itemCard.addView(bulletCol);
            }

            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
            cardLp.bottomMargin = UI.dp(this, 10);
            resultContainer.addView(itemCard, cardLp);
        }
    }

    private void toggleAudio(QwenEngine.SummaryItem item, TextView badgeView) {
        if (item.audioPath == null || item.audioPath.isEmpty()) {
            Toast.makeText(this, "Аудиозапись отсутствует", Toast.LENGTH_SHORT).show();
            return;
        }

        File f = new File(item.audioPath);
        if (!f.exists() || f.length() == 0) {
            Toast.makeText(this, "Аудиофайл очищен по правилу 7 дней (текст сохранён)", Toast.LENGTH_SHORT).show();
            return;
        }

        if (item.audioPath.equals(currentlyPlayingAudioPath) && player != null && player.isPlaying()) {
            stopPlayback();
            return;
        }

        stopPlayback();

        try {
            player = new MediaPlayer();
            player.setDataSource(item.audioPath);
            player.prepare();
            player.setOnCompletionListener(mp -> stopPlayback());
            player.start();

            currentlyPlayingAudioPath = item.audioPath;
            activePlayingBadge = badgeView;

            badgeView.setText("⏹ " + item.time);
            badgeView.setTextColor(Color.WHITE);
            badgeView.setBackground(UI.buttonRipple(UI.gradient(0xFFB91C1C, 0xFFEF4444, 8, this), 0x55FFFFFF));

            Toast.makeText(this, "Воспроизведение [" + item.time + "]", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            stopPlayback();
            Toast.makeText(this, "Ошибка воспроизведения: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void stopPlayback() {
        if (player != null) {
            try {
                if (player.isPlaying()) player.stop();
                player.release();
            } catch (Exception ignored) {}
            player = null;
        }
        if (activePlayingBadge != null) {
            String txt = activePlayingBadge.getText().toString();
            if (txt.startsWith("⏹ ")) {
                activePlayingBadge.setText("▶ " + txt.substring(2));
            }
            activePlayingBadge.setTextColor(UI.COLOR_ORANGE_LIGHT);
            activePlayingBadge.setBackground(UI.buttonRipple(UI.shape(0xFF221710, UI.COLOR_ORANGE_BORDER, 8, this), 0x33F47721));
            activePlayingBadge = null;
        }
        currentlyPlayingAudioPath = null;
    }

    @Override
    protected void onPause() {
        stopPlayback();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        stopPlayback();
        super.onDestroy();
    }
}
