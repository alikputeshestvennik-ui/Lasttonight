package com.blackbox.offline;

import android.content.Context;
import android.os.Environment;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * 100% Offline Markdown / Text / Backup Exporter.
 * Exports your private journal directly into the device Downloads or app-documents directory
 * for Obsidian, Logseq, Notion or local PC backup without any internet connection.
 */
public final class ExportManager {
    private ExportManager() {}

    public static File exportToMarkdown(Context c) throws Exception {
        ArrayList<Entry> entries = new EntryStore(c).all();
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(new Date());
        String fileName = "Blackbox_Journal_" + timeStamp + ".md";

        File exportDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        if (exportDir == null || !exportDir.exists()) {
            exportDir = new File(c.getExternalFilesDir(null), "exports");
            exportDir.mkdirs();
        }

        File outFile = new File(exportDir, fileName);

        StringBuilder sb = new StringBuilder();
        sb.append("# 🎙️ Blackbox Offline Audio Journal\n");
        sb.append("*Сформировано: ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date())).append("*\n");
        sb.append("*Всего записей: ").append(entries.size()).append("*\n\n");
        sb.append("---\n\n");

        for (Entry e : entries) {
            String star = e.important ? " ⭐ **[ВАЖНО]**" : "";
            sb.append("## ").append(e.created).append(star).append("\n");
            sb.append("- **Категория**: `").append(e.category != null ? e.category : "Общее").append("`\n");
            sb.append("- **Длительность**: ").append(e.duration).append(" сек\n");
            sb.append("- **Статус**: ").append(e.status).append("\n\n");
            sb.append("### Расшифровка:\n");
            String t = (e.transcript == null || e.transcript.trim().isEmpty()) ? "*Текст отсутствует или в очереди.*" : e.transcript.trim();
            sb.append(t).append("\n\n");
            sb.append("---\n\n");
        }

        try (FileOutputStream fos = new FileOutputStream(outFile);
             OutputStreamWriter writer = new OutputStreamWriter(fos, StandardCharsets.UTF_8)) {
            writer.write(sb.toString());
            writer.flush();
        }

        return outFile;
    }
}
