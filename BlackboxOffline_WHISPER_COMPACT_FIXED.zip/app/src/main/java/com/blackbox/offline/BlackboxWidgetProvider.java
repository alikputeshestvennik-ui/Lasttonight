package com.blackbox.offline;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;

public class BlackboxWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_TOGGLE = "com.blackbox.offline.WIDGET_TOGGLE";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        boolean isActive = RecordingService.isRecordingActive;
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId, isActive);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent != null ? intent.getAction() : "";

        if (ACTION_TOGGLE.equals(action)) {
            boolean active = RecordingService.isRecordingActive;
            Intent serviceIntent = new Intent(context, RecordingService.class);
            if (active) {
                serviceIntent.setAction(RecordingService.STOP);
                context.startService(serviceIntent);
                updateAllWidgets(context, false);
            } else {
                serviceIntent.setAction(RecordingService.START);
                if (Build.VERSION.SDK_INT >= 26) {
                    context.startForegroundService(serviceIntent);
                } else {
                    context.startService(serviceIntent);
                }
                updateAllWidgets(context, true);
            }
        } else if (RecordingService.STATE.equals(action)) {
            boolean active = intent.getBooleanExtra("active", false);
            updateAllWidgets(context, active);
        }
    }

    public static void updateAllWidgets(Context context, boolean isActive) {
        try {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            ComponentName widgetName = new ComponentName(context, BlackboxWidgetProvider.class);
            int[] ids = manager.getAppWidgetIds(widgetName);
            if (ids != null && ids.length > 0) {
                for (int id : ids) {
                    updateWidget(context, manager, id, isActive);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int widgetId, boolean isActive) {
        String pkg = context.getPackageName();
        int layoutId = context.getResources().getIdentifier("widget_blackbox", "layout", pkg);
        if (layoutId == 0) return;

        RemoteViews views = new RemoteViews(pkg, layoutId);

        int rootId = context.getResources().getIdentifier("widget_root", "id", pkg);
        int logoId = context.getResources().getIdentifier("widget_logo", "id", pkg);
        int infoId = context.getResources().getIdentifier("widget_info_col", "id", pkg);
        int statusId = context.getResources().getIdentifier("widget_status", "id", pkg);
        int btnId = context.getResources().getIdentifier("widget_btn_toggle", "id", pkg);

        int pauseIconRes = context.getResources().getIdentifier("ic_widget_pause", "drawable", pkg);
        int playIconRes = context.getResources().getIdentifier("ic_widget_play", "drawable", pkg);
        int bgActiveRes = context.getResources().getIdentifier("widget_btn_active_bg", "drawable", pkg);
        int bgNormalRes = context.getResources().getIdentifier("widget_btn_bg", "drawable", pkg);

        // 1. Click on widget body opens RecorderActivity
        Intent openAppIntent = new Intent(context, RecorderActivity.class);
        PendingIntent openAppPi = PendingIntent.getActivity(
                context,
                0,
                openAppIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        if (rootId != 0) views.setOnClickPendingIntent(rootId, openAppPi);
        if (logoId != 0) views.setOnClickPendingIntent(logoId, openAppPi);
        if (infoId != 0) views.setOnClickPendingIntent(infoId, openAppPi);

        // 2. Click on Play/Pause button toggles background recording
        Intent toggleIntent = new Intent(context, BlackboxWidgetProvider.class).setAction(ACTION_TOGGLE);
        PendingIntent togglePi = PendingIntent.getBroadcast(
                context,
                1,
                toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
        if (btnId != 0) {
            views.setOnClickPendingIntent(btnId, togglePi);
        }

        // 3. Update dynamic visual states
        if (statusId != 0) {
            if (isActive) {
                views.setTextViewText(statusId, "● Идёт запись");
                views.setTextColor(statusId, 0xFFEF4444);
            } else {
                views.setTextViewText(statusId, "Запись выключена");
                views.setTextColor(statusId, 0xFF8E95A2);
            }
        }

        if (btnId != 0) {
            if (isActive) {
                if (pauseIconRes != 0) views.setImageViewResource(btnId, pauseIconRes);
                if (bgActiveRes != 0) views.setInt(btnId, "setBackgroundResource", bgActiveRes);
            } else {
                if (playIconRes != 0) views.setImageViewResource(btnId, playIconRes);
                if (bgNormalRes != 0) views.setInt(btnId, "setBackgroundResource", bgNormalRes);
            }
        }

        manager.updateAppWidget(widgetId, views);
    }
}
