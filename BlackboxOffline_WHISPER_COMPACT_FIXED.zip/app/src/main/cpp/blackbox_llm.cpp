#include <jni.h>
#include <android/log.h>
#include <string>
#include <vector>
#include <mutex>

// Нейро-ядро Qwen через llama.cpp (тег b3403, июль 2024).
// ВАЖНО: здесь СТАРЫЙ API сэмплирования (llama_sample_*), загрузка через
// llama_load_model_from_file, токенизация/детокенизация по llama_model,
// llama_batch_get_one на 4 аргумента. Новый sampler-chain API и
// llama_model_load_from_file появились только в конце 2024.
#ifdef BLACKBOX_WITH_LLAMA
#include "llama.h"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,"BlackboxLLM",__VA_ARGS__)
#endif

static std::mutex g_llm_mutex;
static std::string g_model_path;

#ifdef BLACKBOX_WITH_LLAMA
static llama_model*   g_model = nullptr;
static llama_context* g_ctx   = nullptr;
#endif

extern "C" JNIEXPORT jint JNICALL
Java_com_blackbox_offline_LlmEngine_nativePing(JNIEnv*, jclass) {
#ifdef BLACKBOX_WITH_LLAMA
    return 1;
#else
    return 0;
#endif
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_blackbox_offline_LlmEngine_nativeGenerate(JNIEnv *env, jclass,
        jstring jModel, jstring jPrompt, jint maxTokens, jfloat temp) {
#ifndef BLACKBOX_WITH_LLAMA
    (void)env; (void)jModel; (void)jPrompt; (void)maxTokens; (void)temp;
    return env->NewStringUTF("LLM-недоступен: llama.cpp не подключён при сборке");
#else
    const char* mp = env->GetStringUTFChars(jModel, nullptr);
    const char* pp = env->GetStringUTFChars(jPrompt, nullptr);
    std::string modelPath(mp), prompt(pp);
    env->ReleaseStringUTFChars(jModel, mp);
    env->ReleaseStringUTFChars(jPrompt, pp);

    std::lock_guard<std::mutex> lock(g_llm_mutex);

    if (g_model == nullptr || g_model_path != modelPath) {
        llama_backend_init();
        llama_model_params mparams = llama_model_default_params();
        mparams.n_gpu_layers = 0; // чистый CPU, офлайн
        mparams.use_mmap = true;
        llama_model* m = llama_load_model_from_file(modelPath.c_str(), mparams);
        if (m == nullptr) return env->NewStringUTF("LLM-ошибка: не удалось загрузить qwen.gguf");
        llama_context_params cparams = llama_context_default_params();
        cparams.n_ctx = 2048;
        cparams.n_batch = 512;
        cparams.n_threads = 4;
        cparams.n_threads_batch = 4;
        llama_context* ctx = llama_new_context_with_model(m, cparams);
        if (ctx == nullptr) { llama_free_model(m); return env->NewStringUTF("LLM-ошибка: не удалось создать контекст"); }
        if (g_ctx != nullptr) llama_free(g_ctx);
        if (g_model != nullptr) llama_free_model(g_model);
        g_model = m; g_ctx = ctx; g_model_path = modelPath;
        LOGI("llama model loaded: %s", modelPath.c_str());
    }

    const int n_vocab = llama_n_vocab(g_model);
    const llama_token eos = llama_token_eos(g_model);

    // Qwen2.5 chat template
    std::string full =
        "<|im_start|>system\n"
        "Ты — Blackbox, локальный автономный ассистент личного дневника. "
        "Отвечай кратко: 1-3 предложения, только по фактам из контекста, на русском. "
        "Если данных в контексте нет — честно скажи об этом.<|im_end|>\n"
        "<|im_start|>user\n" + prompt + "<|im_end|>\n"
        "<|im_start|>assistant\n";

    std::vector<llama_token> tokens(4096);
    int n = llama_tokenize(g_model, full.c_str(), (int)full.size(),
                           tokens.data(), (int)tokens.size(), true, true);
    if (n < 0) n = llama_tokenize(g_model, full.c_str(), (int)full.size(),
                                  tokens.data(), (int)tokens.size(), true, false);
    if (n <= 0) return env->NewStringUTF("LLM-ошибка: не удалось разобрать промпт");

    llama_kv_cache_clear(g_ctx);

    llama_pos cur_pos = 0;
    for (int i = 0; i < n; i += 512) {
        int chunk = n - i < 512 ? n - i : 512;
        llama_batch batch = llama_batch_get_one(tokens.data() + i, chunk, cur_pos, 0);
        if (llama_decode(g_ctx, batch) != 0) return env->NewStringUTF("LLM-ошибка: сбой декодирования промпта");
        cur_pos += chunk;
    }

    std::vector<llama_token_data> candidates(n_vocab);
    std::string out;
    const int limit = maxTokens > 0 ? maxTokens : 300;
    for (int step = 0; step < limit; step++) {
        float* logits = llama_get_logits(g_ctx);
        if (logits == nullptr) break;
        for (int id = 0; id < n_vocab; id++) {
            candidates[id].id = id;
            candidates[id].logit = logits[id];
            candidates[id].p = 0.0f;
        }
        llama_token_data_array arr;
        arr.data = candidates.data();
        arr.size = (size_t) n_vocab;
        arr.sorted = false;
        llama_sample_softmax(g_ctx, &arr);
        llama_token tok;
        if (temp <= 0.0f) {
            tok = llama_sample_token_greedy(g_ctx, &arr);
        } else {
            llama_sample_top_k(g_ctx, &arr, 40, 1);
            llama_sample_temp(g_ctx, &arr, temp);
            tok = llama_sample_token(g_ctx, &arr);
        }
        if (tok == eos) break;
        char buf[256];
        int len = llama_token_to_piece(g_model, tok, buf, sizeof(buf), 0, false);
        if (len > 0) out.append(buf, len);
        llama_token single = tok;
        llama_batch b = llama_batch_get_one(&single, 1, cur_pos, 0);
        cur_pos++;
        if (llama_decode(g_ctx, b) != 0) break;
    }

    llama_kv_cache_clear(g_ctx);
    if (out.empty()) return env->NewStringUTF("LLM-ошибка: пустой ответ модели");
    return env->NewStringUTF(out.c_str());
#endif
}
