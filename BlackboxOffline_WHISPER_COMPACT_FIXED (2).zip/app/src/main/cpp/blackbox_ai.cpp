#include <jni.h>
#include <android/log.h>
#include <string>
#include <mutex>
#include <thread>
#include "whisper.h"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR,"BlackboxAI",__VA_ARGS__)

// Пул из двух независимых контекстов whisper: веса модели разделяются между
// ними через mmap, поэтому два контекста позволяют расшифровывать ДВА
// фрагмента параллельно — длинная запись больше не блокирует очередь.
static whisper_context* g_ctx_a = nullptr;
static whisper_context* g_ctx_b = nullptr;
static std::mutex g_mu_a;
static std::mutex g_mu_b;
static std::string g_path_a;
static std::string g_path_b;

static whisper_context* load_ctx(const std::string& model) {
    whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    return whisper_init_from_file_with_params(model.c_str(), cp);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_blackbox_offline_LocalAiEngine_nativeWarm(JNIEnv *env, jobject, jstring modelPath) {
    const char *path = env->GetStringUTFChars(modelPath, nullptr);
    std::string model(path);
    env->ReleaseStringUTFChars(modelPath, path);
    {
        std::lock_guard<std::mutex> lock(g_mu_a);
        if (!g_ctx_a || g_path_a != model) {
            if (g_ctx_a) whisper_free(g_ctx_a);
            g_ctx_a = load_ctx(model); g_path_a = model;
        }
    }
    {
        std::lock_guard<std::mutex> lock(g_mu_b);
        if (!g_ctx_b || g_path_b != model) {
            if (g_ctx_b) whisper_free(g_ctx_b);
            g_ctx_b = load_ctx(model); g_path_b = model;
        }
    }
    return (g_ctx_a && g_ctx_b) ? JNI_TRUE : JNI_FALSE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_blackbox_offline_LocalAiEngine_nativeTranscribePcm(JNIEnv *env,jobject,jfloatArray pcm,jstring modelPath){
    const char *path=env->GetStringUTFChars(modelPath,nullptr);
    std::string model(path);
    env->ReleaseStringUTFChars(modelPath,path);

    // Выбираем свободный контекст: A, иначе B (длинная запись на A
    // не мешает коротким проходить через B).
    whisper_context* ctx = nullptr;
    std::unique_lock<std::mutex> la(g_mu_a, std::defer_lock);
    std::unique_lock<std::mutex> lb(g_mu_b, std::defer_lock);
    la.try_lock();
    if (la.owns_lock()) {
        if (!g_ctx_a || g_path_a != model) {
            if (g_ctx_a) { whisper_free(g_ctx_a); g_ctx_a = nullptr; }
            g_ctx_a = load_ctx(model); g_path_a = model;
        }
        ctx = g_ctx_a;
    } else {
        lb.lock();
        if (!g_ctx_b || g_path_b != model) {
            if (g_ctx_b) { whisper_free(g_ctx_b); g_ctx_b = nullptr; }
            g_ctx_b = load_ctx(model); g_path_b = model;
        }
        ctx = g_ctx_b;
    }
    if (!ctx) return env->NewStringUTF("Ошибка: не удалось открыть Whisper-модель.");

    jsize n=env->GetArrayLength(pcm);
    jfloat *audio=env->GetFloatArrayElements(pcm,nullptr);
    whisper_full_params p=whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    p.print_progress=false;p.print_realtime=false;p.print_timestamps=false;
    p.translate=false;p.language="ru";p.no_timestamps=true;
    unsigned int hc=std::thread::hardware_concurrency();
    p.n_threads = hc>=4 ? 4 : (hc>0 ? hc : 1);
    int rc=whisper_full(ctx,p,audio,n);
    env->ReleaseFloatArrayElements(pcm,audio,JNI_ABORT);
    if(rc!=0){return env->NewStringUTF("Ошибка: Whisper не смог обработать запись.");}
    std::string result;
    for(int i=0;i<whisper_full_n_segments(ctx);i++){const char *s=whisper_full_get_segment_text(ctx,i);if(s)result+=s;}
    if(result.empty())result="[Речь не распознана]";
    return env->NewStringUTF(result.c_str());
}
